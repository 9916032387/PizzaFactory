package com.qualys.entity;

public enum Crust {

    NewHandTossed,
    WheatThinCrust,
    CheeseBurst,
    FreshPanPizza
}
