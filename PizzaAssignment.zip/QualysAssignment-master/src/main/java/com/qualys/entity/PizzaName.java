package com.qualys.entity;

public enum PizzaName {

    DeluxeVeggie,
    CheeseAndCorn,
    PaneerTikka,
    NonVegSupreme,
    ChickenTikka,
    PepperBarbecueChicken
}
