package com.qualys.entity;

public enum PizzaType {

    VEG,
    NON_VEG
}
