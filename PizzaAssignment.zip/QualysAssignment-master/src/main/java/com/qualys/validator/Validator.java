package com.qualys.validator;

import com.qualys.entity.Pizza;

public interface Validator {

    void execute(Pizza pizza);
}
